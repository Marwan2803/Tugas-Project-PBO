package model;

public interface Trainable {
    void train();
}
